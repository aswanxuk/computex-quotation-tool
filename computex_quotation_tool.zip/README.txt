
Computex Quotation Tool - Deployment Guide

1. Go to https://vercel.com/
2. Click 'New Project' -> 'Import Manually' -> Upload this ZIP
3. Deploy and get your link!

Features:
- New/Edit Quotation
- Item Table Entry (Qty, Price, GST%)
- Auto Calculation
- PDF Export with Logo
- Save Draft (Local Storage)
